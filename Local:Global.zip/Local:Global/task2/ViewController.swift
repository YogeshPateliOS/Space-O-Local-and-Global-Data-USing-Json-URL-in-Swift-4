//
//  ViewController.swift
//  task2
//
//  Created by SOTSYS027 on 17/01/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit
import SwiftyJSON
import Kingfisher

struct celldataDM {
    var trackCensoredName:String = ""
    var artistName :String = ""
    var releaseDate :String = ""
    var trackPrice :String = ""
    var artworkUrl100 :String = ""
    
    var wrapperType:String = ""
    var kind :String = ""
    var artistId :String = ""
    var collectionId :String = ""
    var trackId :String = ""
    
    var collectionName:String = ""
    var collectionCensoredName :String = ""
    var artistViewUrl :String = ""
    var collectionViewUrl :String = ""
    var trackViewUrl :String = ""
    
    var previewUrl:String = ""
    var artworkUrl30 :String = ""
    var artworkUrl60 :String = ""
    var collectionPrice :String = ""
    var collectionExplicitness :String = ""
    
    var trackExplicitness:String = ""
    var discCount :String = ""
    var discNumber :String = ""
    var trackCount :String = ""
    var trackNumber :String = ""
    
    var trackTimeMillis:String = ""
    var country :String = ""
    var currency :String = ""
    var primaryGenreName :String = ""
    var isStreamable :String = ""
    
    
    init() {
    }
    
    init(json : JSON) {
        trackCensoredName = json["trackCensoredName"].stringValue
          artistName = json["artistName"].stringValue
          releaseDate = json["releaseDate"].stringValue
          trackPrice = json["trackPrice"].stringValue
          artworkUrl100 = json["artworkUrl100"].stringValue
        
        wrapperType = json["wrapperType"].stringValue
        kind = json["kind"].stringValue
        artistId = json["artistId"].stringValue
        collectionId = json["collectionId"].stringValue
        trackId = json["trackId"].stringValue
        
        collectionName = json["collectionName"].stringValue
        collectionCensoredName = json["collectionCensoredName"].stringValue
        artistViewUrl = json["artistViewUrl"].stringValue
        collectionViewUrl = json["collectionViewUrl"].stringValue
        collectionExplicitness = json["collectionExplicitness"].stringValue
        
        previewUrl = json["previewUrl"].stringValue
        artworkUrl30 = json["artworkUrl30"].stringValue
        artworkUrl60 = json["artworkUrl60"].stringValue
        collectionPrice = json["collectionPrice"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
        
        trackExplicitness = json["trackExplicitness"].stringValue
        discCount = json["discCount"].stringValue
        discNumber = json["discNumber"].stringValue
        trackCount = json["trackCount"].stringValue
        trackNumber = json["trackNumber"].stringValue
        
        trackCensoredName = json["trackCensoredName"].stringValue
        artistName = json["artistName"].stringValue
        releaseDate = json["releaseDate"].stringValue
        trackPrice = json["trackPrice"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
        
        trackTimeMillis = json["trackTimeMillis"].stringValue
        country = json["country"].stringValue
        currency = json["currency"].stringValue
        primaryGenreName = json["primaryGenreName"].stringValue
        isStreamable = json["isStreamable"].stringValue
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var searchcontroller: UISearchBar!
    var arrdata = [celldataDM]()
   var searchActive: Bool = false
  var filtered: [celldataDM] = []
    var arrdata2 = ["aasdasd","aasdasd","aasdasd","aasdasd","aasdasd","aasdasd","aasdasd","aasdasd"]
  //  var maincelldata: celldataDM!
    
    @IBOutlet weak var mysegment: UISegmentedControl!
    
    @IBAction func btnseg(_ sender: UISegmentedControl) {
        self.tableview.reloadData()
    }
    
    
  @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       swiftyjson()
    }
   
    //SeacrhBar Method..

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
       searchActive = false
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
       searchActive = false
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
       searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText == ""
        {
            searchActive = false
        }else{
            searchActive = true
        }
        filtered = arrdata.filter {
            return $0.artistName.contains(searchText)
        }
//        filtered = arrdata.filter{
//            let urlstring = "https://itunes.apple.com/search?media=music&term=" + searchText
//
//        }
       self.tableview.reloadData()
    }
    
    //Json Stuff is Here..
    func swiftyjson(){
        guard let url = URL(string: "https://itunes.apple.com/search?media=music&term=bollywood") else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                //Swiftyjson Code here..
                let json = try JSON(data: data)
                print(json)
                let dict = json["results"]
             
                print(dict)
                for arr in dict.arrayValue{
                    self.arrdata.append(celldataDM(json: arr))
                }
                 print(self.arrdata)

                
                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
            }catch{
                print("error")
            }
        }.resume()
    }
 
   // DateFormat Code Here
    func formattedDateFromString(dateString: String, withFormat format: String) -> String? {

        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"//input format

        if let date = inputFormatter.date(from: dateString) {

            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = format//Output format

            return outputFormatter.string(from: date)
        }

        return nil
    }
    
  //  TableView Methods implementation
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var returnvalue = 0
        switch mysegment.selectedSegmentIndex {
        case 0:
            
            returnvalue =  arrdata.count
         
            if searchActive{
            return filtered.count
                
            }else{
                
                
                return arrdata.count
            }
            
            break
        case 1:
            returnvalue = arrdata2.count
            break
        default:
            print("Error in rowssection")
            break
        }
       return returnvalue
//        if searchActive {
//            return filtered.count
//        }else{
//        return arrdata.count
//    }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
       
        switch mysegment.selectedSegmentIndex {
        case 0:
            if searchActive{
                cell.lbl1.text = filtered[indexPath.row].trackCensoredName
                cell.lbl2.text = filtered[indexPath.row].artistName
                let maindate = formattedDateFromString(dateString:filtered[indexPath.row].releaseDate, withFormat: "MM/dd/yyyy")
                cell.lbl3.text = maindate
                cell.lbl4.text = "$\(filtered[indexPath.row].trackPrice)"
                let mainimg = ImageResource(downloadURL: URL(string: filtered[indexPath.row].artworkUrl100)! , cacheKey: filtered[indexPath.row].artworkUrl100)
                cell.img.kf.setImage(with: mainimg)
                
            }
            else
            {
                cell.lbl1.text = arrdata[indexPath.row].trackCensoredName
                cell.lbl2.text = arrdata[indexPath.row].artistName
                let maindate = formattedDateFromString(dateString:arrdata[indexPath.row].releaseDate, withFormat: "MM/dd/yyyy")
                cell.lbl3.text = maindate
                cell.lbl4.text = "$\(arrdata[indexPath.row].trackPrice)"
                let mainimg = ImageResource(downloadURL: URL(string: arrdata[indexPath.row].artworkUrl100)! , cacheKey: arrdata[indexPath.row].artworkUrl100)
                cell.img.kf.setImage(with: mainimg)
                
            }
            break
        case 1:
            cell.lbl1.text = arrdata2[indexPath.row]
            break
        default:
            print("error cellfor")
        }
        
        
       
        return cell
        
    }
    
   // Dynamic Height for AutoLayout Constrain
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }

  

}
